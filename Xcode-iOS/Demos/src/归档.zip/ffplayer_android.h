//
//  ffplayer_android.h
//  Rectangles
//
//  Created by huangjunren on 2017/11/29.
//

#ifndef ffplayer_android_h
#define ffplayer_android_h

#include <stdio.h>
#include <stdlib.h>
#include "SDL.h"
#include <libavutil/avstring.h>
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libavutil/samplefmt.h"
#include "libswresample/swresample.h"
#include "SDL.h"
#include "SDL_thread.h"
#include "SDL_events.h"
#include "libavutil/pixfmt.h"

#define SDL_AUDIO_BUFFER_SIZE 1024

#define MAX_AUDIOQ_SIZE (5 * 16 * 1024)
#define MAX_VIDEOQ_SIZE (5 * 256 * 1024)

#define AV_SYNC_THRESHOLD 0.01
#define AV_NOSYNC_THRESHOLD 10.0

#define SAMPLE_CORRECTION_PERCENT_MAX 10
#define AUDIO_DIFF_AVG_NB 20

#define FF_ALLOC_EVENT   (SDL_USEREVENT)
#define FF_REFRESH_EVENT (SDL_USEREVENT + 1)
#define FF_QUIT_EVENT (SDL_USEREVENT + 2)

#define VIDEO_PICTURE_QUEUE_SIZE 1

//#define DEFAULT_AV_SYNC_TYPE AV_SYNC_VIDEO_MASTER
#define DEFAULT_AV_SYNC_TYPE AV_SYNC_AUDIO_MASTER
//#define DEFAULT_AV_SYNC_TYPE AV_SYNC_EXTERNAL_MASTER
#define AVCODEC_MAX_AUDIO_FRAME_SIZE 192000 // 1 second of 48khz 32bit audio
//#define  LOG_TAG    "player"
//#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
//#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
//#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)

typedef struct PacketQueue {
    AVPacketList *first_pkt, *last_pkt;
    int nb_packets;
    int size;
    SDL_mutex *mutex;
    SDL_cond *cond;
} PacketQueue;

typedef struct VideoPicture {
    SDL_Window *screen;
    SDL_Renderer *renderer;
    SDL_Texture *bmp;
    
    AVFrame* rawdata;
    int width, height; /*source height & width*/
    int allocated;
    double pts;
} VideoPicture;

typedef struct VideoState {
    char filename[1024];
    AVFormatContext *ic;
    int videoStream, audioStream;
    AVStream *audio_st;
    AVFrame *audio_frame;
    PacketQueue audioq;
    unsigned int audio_buf_size;
    unsigned int audio_buf_index;
    AVPacket audio_pkt;
    uint8_t *audio_pkt_data;
    int audio_pkt_size;
    uint8_t *audio_buf;
    DECLARE_ALIGNED(16,uint8_t,audio_buf2) [AVCODEC_MAX_AUDIO_FRAME_SIZE * 4];
    enum AVSampleFormat audio_src_fmt;
    enum AVSampleFormat audio_tgt_fmt;
    int audio_src_channels;
    int audio_tgt_channels;
    int64_t audio_src_channel_layout;
    int64_t audio_tgt_channel_layout;
    int audio_src_freq;
    int audio_tgt_freq;
    struct SwrContext *swr_ctx;                     // audio 重采样转换器
    
    AVStream *video_st;
    PacketQueue videoq;
    
    // Video FrameQueue
    VideoPicture pictq[VIDEO_PICTURE_QUEUE_SIZE];
    int pictq_size, pictq_rindex, pictq_windex;
    SDL_mutex *pictq_mutex;
    SDL_cond *pictq_cond;
    
    SDL_mutex *audio_mutex;
    SDL_cond *audio_cond;
    
    SDL_mutex *recv_mutex;
    SDL_cond *recv_cond;
    
    SDL_Thread *parse_tid;
    SDL_Thread *audio_tid;
    SDL_Thread *video_tid;
    
    AVIOContext *io_ctx;
    struct SwsContext *sws_ctx;                     // video 格式转换器
    
    double audio_clock;
    
    int av_sync_type;
    double external_clock;/*external clock base*/
    int64_t external_clock_time;
    
    int audio_hw_buf_size;
    double audio_diff_cum;/*used of AV difference average computation*/
    double audio_diff_avg_coef;
    double audio_diff_threshold;
    int audio_diff_avg_count;
    double frame_timer;
    double frame_last_pts;
    double frame_last_delay;
    
    double video_current_pts; ///<current displayed pts (different from video_clock if frame fifos are used)
    int64_t video_current_pts_time; ///<time (av_gettime) at which we updated video_current_pts - used to have running video pts
    
    double video_clock; ///<pts of last decoded frame / predicted pts of next decoded frame
    
    //quit = -2 : 未开始初始化函数
    //quit = -1 : 完成ffmpeg相关属性的初始化
    //quit = 0 : 正常开始进行视频的播放
    //quit = 1 : 退出当前视频的播放
    int quit;
    
    // for seek stream
    int seek_req;
    int64_t seek_pos;
    int64_t seek_rel;
    int seek_flags;
    SDL_cond *continue_read_thread;
    
    // 视频总时长
    int64_t duration;
    double totalTimes;
    
    AVCodecContext * audio_codec_ctx;
    AVCodecContext * video_codec_ctx;
    int paused;
    SDL_TimerID lastAddTimer;
    Uint32 event;
    
    int backed;
    
} VideoState;

// 音视频同步方式
// AV_SYNC_AUDIO_MASTER：默认方式 视频同步音频
// AV_SYNC_VIDEO_MASTER: 音频同步视频
enum {
    AV_SYNC_AUDIO_MASTER, AV_SYNC_VIDEO_MASTER, AV_SYNC_EXTERNAL_MASTER,
};

void audio_callback(void *userdata, Uint8 *stream, int len);
int decode_interrupt_cb(void *opaque);
void frame_queue_unref_item(VideoPicture *vp);
void free_picture(VideoPicture *vp);
void frame_queue_destory(VideoState *is);
void packet_queue_destroy(PacketQueue *q);
void packet_queue_abort(PacketQueue *q);
void audio_abort(VideoState *is);
void frame_queue_signal(VideoState *is);
void video_abort(VideoState *is);
void audio_decoder_destroy(VideoState *is);
void video_decoder_destroy(VideoState *is);
void stream_component_close(VideoState *is, int stream_index);
void stream_close(VideoState *is);


static AVPacket flush_pkt;
VideoState *global_video_state;
// 入口函数
int native_init(const char *file_path);
//int init_play(const char *file_path);
//int init_play(VideoState *is);
int init_play(const char* inPath);
void set_stream_timer(VideoState *is);
void stream_seek(VideoState *is, int64_t pos, int64_t rel, int seek_by_bytes);
void setIsBackedFromJava(VideoState *is,int backed);
int get_current_position(VideoState *is);
int get_duration(VideoState *is);
// pause or resume
void toggle_pause(VideoState *is);

void stream_open_jni(const char* url);
void stream_close_jni(VideoState *is);

//新接口播放使用示例
void init_new_play(const char* file_path);
//SDL事件循环处理函数
void sdl_loop(VideoState *is);
//视频播放线程
int video_new_thread(void *args);
//视频接收线程
int decode_new_thread(void *args);
//sdl相关属性信息初始化，需要在ffmpeg_open之后被调用
int sdl_open(VideoState *is, int isInThread);
//sdl相关音频属性信息初始化，需要在ffmpeg_open之后被调用
int sdl_audio_open(VideoState *is);
//sdl相关属性信息初始化，需要在global_video_state_create之后被调用
int ffmpeg_open(const char *file_path);
//global_video_state被销毁，需要在sdl_close和ffmpeg_close方法之后被调用
int global_video_state_destory();
//global_video_state被创建，需要在sdl_open，sdl_audio_open和ffmpeg_open方法之前被调用
VideoState * global_video_state_create();
//sdl相关属性被释放，需要在ffmpeg_close后被释放
void sdl_close(VideoState *is);
//ffmpeg相关属性被释放
void ffmpeg_close(VideoState *is);

#endif /* ffplayer_android_h */
